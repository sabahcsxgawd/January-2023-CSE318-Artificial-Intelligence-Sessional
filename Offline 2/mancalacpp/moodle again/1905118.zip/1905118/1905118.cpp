#include <bits/stdc++.h>
using namespace std;

#include "GameState.h"
#include "Heuristic.h"
#include "Player.h"
#include "PlayStyles.h"


int main(int argc, char* argv[]) {

    Play_AI_vs_AI();
    // Play_HUMAN_vs_AI();
    // Play_HUMAN_vs_HUMAN();
    //  generateReport();
    return 0;

}