package N_Puzzle;

public interface Solution {
    public Node solve();

}
